<?php
$conn = new mysqli("localhost", "root", "", "my_rollo")
    or die("Connessione non avvenuta" . $conn->connect_error);
