<?php
function sendOTP($email, $otp)
{
    return;
}
